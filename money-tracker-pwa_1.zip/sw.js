const CACHE = 'money-tracker-v1';
self.addEventListener('install', function(event){
  event.waitUntil(caches.open(CACHE).then(function(cache){ return cache.add('./index.html'); }));
  self.skipWaiting();
});
self.addEventListener('activate', function(event){ self.clients.claim(); });
self.addEventListener('fetch', function(event){
  event.respondWith(
    caches.match(event.request).then(function(cached){ return cached || fetch(event.request); })
  );
});
